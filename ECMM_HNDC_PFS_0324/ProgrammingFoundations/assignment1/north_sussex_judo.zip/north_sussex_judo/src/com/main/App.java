package com.main;

import java.util.*;

/**
 * Classname: App
 * Version information: 1.0
 * Date: 12/04/2024
 * Author: Sai Han Htet
 * Description: – To keep tracking the athlete of the North Judo Training Club
 */

public class App {

  // competitive athlete array list and athlete array list
  private static final ArrayList<CompetitiveAthlete> competitiveAthletes = new ArrayList<>();
  private static final ArrayList<Athlete> athletes = new ArrayList<>();

  // temporary variables for storing data
  private static String athleteName;
  private static TrainingPlan trainingPlan;
  private static double currentWeight;
  private static String competitionWeightCategory;
  private static int noOfCompetition = 0;
  private static int privateCoachingHours = 0;

  // scanner object
  private static final Scanner input = new Scanner(System.in);

  /**
   * This method is used to check whether the user is already registered or not based on username.
   * @return boolean
   */
  public static boolean isUserRegistered(String username) {
    username = username.toLowerCase();
    // search in competitve athlete first
    for (CompetitiveAthlete c_user : competitiveAthletes) {
      if (c_user.getName().toLowerCase().equals(username)) {
        return true;
      }
    }
    // search user in athlete class
    for (Athlete a_user : athletes) {
      if (a_user.getName().toLowerCase().equals(username)) {
        return true;
      }
    }
    return false;
  }

  /**
   * This method return the athlete object based on the username
   * @return Object Athlete/CompetitiveAthlete
   */
  public static Object getUserByName(String username) {
    username = username.toLowerCase();
    // search in competitve athlete first
    for (CompetitiveAthlete c_user : competitiveAthletes) {
      if (c_user.getName().toLowerCase().equals(username)) {
        return c_user;
      }
    }
    // search user in athlete class
    for (Athlete a_user : athletes) {
      if (a_user.getName().toLowerCase().equals(username)) {
        return a_user;
      }
    }
    return new Athlete();
  }

  /**
   * This method is for demo users data
   */
  public static void demoData() {
    CompetitiveAthlete user1 = new CompetitiveAthlete(
      "Lucy",
      TrainingPlan.ELITE,
      70
    );
    CompetitiveAthlete user2 = new CompetitiveAthlete(
      "Nick",
      TrainingPlan.INTERMEDIATE,
      68
    );
    CompetitiveAthlete user3 = new CompetitiveAthlete(
      "Peter",
      TrainingPlan.ELITE,
      110
    );
    Athlete user4 = new Athlete("John", TrainingPlan.BEGINNER, 70.0);
    Athlete user5 = new Athlete("Alice", TrainingPlan.INTERMEDIATE, 65.0);
    Athlete user6 = new Athlete("Bob", TrainingPlan.ELITE, 80.0);

    user1.setCompetitionsEntered(2);
    user1.setCompetitionWeightCategory("Middleweight");
    user1.setPrivateCoachingHours(3);
    user2.setCompetitionsEntered(2);
    user2.setCompetitionWeightCategory("LightWeight");
    user2.setPrivateCoachingHours(2);
    user3.setCompetitionsEntered(3);
    user3.setCompetitionWeightCategory("HeavyWeight");
    user3.setPrivateCoachingHours(5);

    // add user1 to 3 to competitive athlete list and user4 to 6 to normal athlete list
    competitiveAthletes.add(user1);
    competitiveAthletes.add(user2);
    competitiveAthletes.add(user3);
    athletes.add(user4);
    athletes.add(user5);
    athletes.add(user6);
  }

  public static void main(String[] args) {
    // add demo data
    demoData();

    // loop the program
    while (true) {
      // welcome message
      System.out.println("Welcome from the North Judo Training");

      while (true) {
        // ask for name and check if the user is exist or not
        System.out.print("Please input user name: ");
        athleteName = input.next();
        boolean existUser = isUserRegistered(athleteName);
        // if user exists then show the information of user or if not break the loop
        if (!existUser) {
          break;
        } else {
          System.out.println("User already existed!");
          System.out.println("=".repeat(30));
          System.out.println("User Information");
          System.out.println("-".repeat(20));
          Object user = getUserByName(athleteName);

          // check the instance of user and save to each list
          if (user instanceof Athlete athlete) {
              ArrayList<String> info = athlete.getAthleteInfo();
            for (String i : info) {
              System.out.println(i);
            }
            System.out.println("=".repeat(30));
          }
        }
      }
      System.out.println();

      // Show the training plan for user with the price
      while (true) {
        System.out.println(
          "Please select the Training Plan below (enter only number):"
        );
        System.out.println("1. Beginner Plan : $ 25.00");
        System.out.println("2. Intermediate Plan : $ 30.00");
        System.out.println("3. Elite Plan : $ 35.00");
        System.out.println("Enter 1 or 2 or 3 only.");
        // request for the training plan
        System.out.print("Enter your plan: ");

        try {
          Integer trainingPlanInput = input.nextInt();
          // check if the input is valid
          if (trainingPlanInput == 1) {
            System.out.println("You have selected the Beginner Plan.");
            trainingPlan = TrainingPlan.BEGINNER; // store the plan instance in traingPlan
            break;
          } else if (trainingPlanInput == 2) {
            System.out.println("You have selected Intermediate Plan.");
            trainingPlan = TrainingPlan.INTERMEDIATE; // store the plan instance in traingPlan
            break;
          } else if (trainingPlanInput == 3) {
            System.out.println("You have selected Elite Plan.");
            trainingPlan = TrainingPlan.ELITE; // store the plan instance in traingPlan
            break;
          } else {
            System.out.println("Please choose 1 to 3 only.");
            System.out.println();
          }
        } catch (Exception e) {
          System.out.println("Please enter number only.");
        }
      }
      System.out.println();

      // Request the user current weight
      while (true) {
        System.out.print("Please enter you current weight: ");
        try {
          currentWeight = Double.parseDouble(input.next());
          if (currentWeight > 0) {
            break;
          } else {
            System.out.println(
              "Please enter your weight. Your weight must be greater than 0."
            );
          }
        } catch (Exception e) {
          System.out.println("Accept only the float value! not text!");
        }
      }
      System.out.println();

      // Ask athlete want to take private coaching
      while (true) {
        System.out.println("Rule: maximum private coaching hours is 5 hours.");
        System.out.println("Cost: $9 dollar for an hour.");
        System.out.print(
          "Do you want to take the private coaching? (yes/no): "
        );
        String answer = input.next();
        // check the input include yes
        if (answer.contains("y")) {
          System.out.println(
            "Ok then, How many hours would you like for private coaching?"
          );
          System.out.print("Enter hours > ");
          try {
            privateCoachingHours = input.nextInt();
            if (privateCoachingHours > 0 && privateCoachingHours <= 5) {
              break;
            } else {
              System.out.println("Please enter valid number between 1 to 5.");
            }
          } catch (Exception e) {
            System.out.println("Please enter only the number.");
          }
        } else {
          break;
        }
      }
      System.out.println();

      boolean willingForCompetition = false;
      // Asking athlete to enter competition if they are not beginner
      if (!trainingPlan.getName().toLowerCase().equalsIgnoreCase("beginner")) {
        while (true) {
          System.out.println(
            "The entry fee for one competition will cost $22 dollar."
          );
          System.out.print(
            "Do you want to enter the competition? (yes/no): "
          );
          String answer = input.next();
          if (answer.contains("y")) {
            willingForCompetition = true;
            System.out.println(
              "Ok, then how many competiton would you like to participate in this month?"
            );
            System.out.print("Enter competition number > ");
            try {
              noOfCompetition = input.nextInt();
              if (noOfCompetition > 0) {
                break;
              } else {
                System.out.println("Please enter valid number.");
              }
            } catch (Exception e) {
              System.out.println("Please enter the number only!");
            }
          } else {
            break;
          }
        }
        System.out.println();

        // Asking for competition weight category.
        while (true) {
          System.out.println("Please choose the weight category from below:");
          System.out.println("1. Heavyweight : Unlimited (over 100)");
          System.out.println("2. Light-Heavyweight : 100");
          System.out.println("3. Middleweight : 90");
          System.out.println("4. Light-Middleweight : 81");
          System.out.println("5. Lightweight : 73");
          System.out.println("6. Flyweight : 66");

          System.out.print("Enter your competition weight category: ");
          try {
            int chosenIntWeightCategory = input.nextInt();

            if (chosenIntWeightCategory == 1) {
              competitionWeightCategory = "Heavyweight";
              break;
            } else if (chosenIntWeightCategory == 2) {
              competitionWeightCategory = "Light-Heavyweight";
              break;
            } else if (chosenIntWeightCategory == 3) {
              competitionWeightCategory = "Middleweight";
              break;
            } else if (chosenIntWeightCategory == 4) {
              competitionWeightCategory = "Light-Middleweight";
              break;
            } else if (chosenIntWeightCategory == 5) {
              competitionWeightCategory = "Lightweight";
              break;
            } else if (chosenIntWeightCategory == 6) {
              competitionWeightCategory = "Flyweight";
              break;
            } else {
              competitionWeightCategory = "";
              System.out.println("Please enter a number between 1 to 6");
            }
          } catch (Exception e) {
            competitionWeightCategory = "";
            System.out.println("Please enter a valid number.");
            input.nextLine();
          }
        }
        System.out.println();
      }

      // Calculate cost and add user into list
      if (willingForCompetition) {
        // create new competitve athlete class
        CompetitiveAthlete user = new CompetitiveAthlete(
          athleteName,
          trainingPlan,
          currentWeight
        );
        user.setCompetitionsEntered(noOfCompetition);
        user.setCompetitionWeightCategory(
          competitionWeightCategory.toLowerCase()
        );
        user.setPrivateCoachingHours(privateCoachingHours);
        // add in the competitive athletes list
        competitiveAthletes.add(user);
        // output the information of competitive athlete
        ArrayList<String> info = user.getAthleteInfo();
        for (String i : info) {
          System.out.println(i);
        }
        System.out.println("=".repeat(30));
      } else {
        // create new athlete user class
        Athlete user = new Athlete(athleteName, trainingPlan, currentWeight);
        user.setPrivateCoachingHours(privateCoachingHours);
        // add in the athletes list
        athletes.add(user);
        // output the information of athlete
        ArrayList<String> info = user.getAthleteInfo();
        for (String i : info) {
          System.out.println(i);
        }
        System.out.println("=".repeat(30));
      }

      // ask the user want to quit or not
      System.out.print("Do you want to quit? (Y/N): ");
      String answer = input.next();
      if (answer.toLowerCase().contains("y")) {
        System.out.println("Thanks for using the North Sussex Judo Program.");
        break;
      }
    }
  }
}
