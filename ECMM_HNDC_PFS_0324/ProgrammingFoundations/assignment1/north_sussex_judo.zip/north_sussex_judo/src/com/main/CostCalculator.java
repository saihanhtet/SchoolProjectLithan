package com.main;

/**
 * Classname: Athlete
 * Version information: 1.0
 * Date: 12/04/2024
 * Author: Sai Han Htet
 */
public interface CostCalculator {
  double calculateCost();
}
